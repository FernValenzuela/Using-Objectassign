# Instructions  

 1. Use `Object.assign()` to cut the unneeded lines of code from the constructor function.
 2. Create a new instance of the `muppet()` constructor.
 3. Call the `summary()` method on the new instance.